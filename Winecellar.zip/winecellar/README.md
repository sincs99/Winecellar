# Android Module FS21

Winecellar APP

## Installation

Use Android Emulator

```bash
tested with Pixel 3a
```

## Tasks

- [x] Create View
- [ ] Implement Function



## Developers

- Pascal Konezciny
- Jonas Mächler
- Dominic Richner


## License
[MIT](https://choosealicense.com/licenses/mit/)
